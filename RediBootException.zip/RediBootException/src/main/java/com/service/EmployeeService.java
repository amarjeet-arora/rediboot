package com.service;

import org.springframework.stereotype.Service;

import com.exceptions.EmployeeServiceException;
import com.model.Employee;

@Service
public class EmployeeService {
	
	
	public Employee getEmployee()  throws EmployeeServiceException{
		Employee e= new Employee();
		
		e.setName("emp1");
		e.setEmpId("101");
		e.setDesignation("finance");
		e.setSalary(3000);
		
		
		return e;
	}
	public Employee getEmployeeNull() throws EmployeeServiceException {
		
		return null;
	}
public Employee getEmployeeException() throws EmployeeServiceException {
		
		throw new EmployeeServiceException();
	}

}
