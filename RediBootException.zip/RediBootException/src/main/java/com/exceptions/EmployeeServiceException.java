package com.exceptions;

public class EmployeeServiceException extends Exception{

	public EmployeeServiceException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public EmployeeServiceException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	

}
