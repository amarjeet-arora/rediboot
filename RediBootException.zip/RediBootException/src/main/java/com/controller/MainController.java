package com.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.exceptions.EmployeeServiceException;
import com.exceptions.ResourceNotFoundException;
import com.model.Employee;
import com.service.EmployeeService;

 

@RestController
 
public class MainController {

	@Autowired
	private EmployeeService employeeService;
	
	@GetMapping("/employee")
	public Employee getemp() throws ResourceNotFoundException,EmployeeServiceException{
		
		Employee em= employeeService.getEmployee();
		
		if(em == null) {
			throw new ResourceNotFoundException("employee not found");
		}
		
		return em;
	}
	 

	@GetMapping("/employee2")
	public Employee getemp2() throws ResourceNotFoundException,EmployeeServiceException{
		
		Employee em= employeeService.getEmployeeNull();
		
		if(em == null) {
			throw new ResourceNotFoundException("employee not found");
		}
		
		return em;
	}
	 

	@GetMapping("/employee3")
	public Employee getemp3() throws ResourceNotFoundException,EmployeeServiceException{
		
		try {
		Employee em= employeeService.getEmployeeException();
		
		if(em == null) {
			throw new ResourceNotFoundException("employee not found");
		}
		
		return em;
		} catch (EmployeeServiceException e) {
		throw new EmployeeServiceException(" internal server error");
		}
	}
	 

}
