package com.example.RediBoot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RediBootApplication {

	public static void main(String[] args) {
		SpringApplication.run(RediBootApplication.class, args);
	}

}
